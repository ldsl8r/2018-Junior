import sys
if 'C:/Users/10796568/Documents/Repositories/Junior2018Work/MayaScripting/scripts' not in sys.path:
    sys.path.append('C:/Users/10796568/Documents/Repositories/Junior2018Work/MayaScripting/scripts')

for p in sys.path:
    print p
